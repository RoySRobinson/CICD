andrewrothstein.unarchive-deps
==============
[![Build Status](https://travis-ci.org/andrewrothstein/ansible-unarchive-deps.svg?branch=master)](https://travis-ci.org/andrewrothstein/ansible-unarchive-deps)

Dependencies for the Ansible unarchive module, et. al.

Example Playbook
----------------

```yml
- hosts: servers
  roles:
    - andrewrothstein.unarchive-deps
```

License
-------

MIT

Author Information
------------------

Andrew Rothstein <andrew.rothstein@gmail.com>
